/*
    Replace bing search
    https://www.bing.com/search?q=QUERY + Other Junk

    With Google Search
    https://www.google.com.au/search?q=QUERY
*/

// RegEx to get the query: \search?q=([Anything thats not a &] as manu times as it appears (until end or &))
query = /\/search\?q=([^&]*)/.exec(location.href)[1]
location.replace('https://www.google.com.au/search?q=' + query)