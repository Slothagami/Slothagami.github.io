window.onload=function() {
	updateTime()
	setInterval(updateTime, 1000 * 15) // Update every 20s
}

function mins(hour, min) {
	// Returns the time of day in minuites
	return hour * 60 + min
}

function updateTime() {
	
	// make body height the screen height
	document.body.style.height = window.innerHeight - 90 + "px"
	
	// Loop the .timetable-item elements and change the bg of
	// the one that matches the current time
	
	var tItems = document.getElementsByClassName('timetable-item'),
		date = new Date(),
		currentTime = mins(date.getHours(), date.getMinutes()),
		times = [ // [start, end] The time ranges that the classes are happening
			[mins( 8,48), mins( 9,00)], // 8:48 to 9:00
			[mins( 9,02), mins(10,02)],
			[mins(10,05), mins(11,05)],
			[mins(11,52), mins(12,52)],
			[mins(12,55), mins(13,55)],
			[mins(14,20), mins(15,20)]
		]
	
	// Update timetable list
	for(var i = 0; i < tItems.length; i++) {
		if(currentTime >= times[i][0] && currentTime <= times[i][1]) {
			tItems[i].style = 'background-color:#4879A1;text-align:center'
			if(tItems[i].id == 'sport'){
				tItems[i].style = 'background-color:#8C3503;text-align:center'
			}
		}else{
			tItems[i].style = 'background-color:#131418'
			if(tItems[i].id == 'sport'){
				tItems[i].style = 'background-color:#8C3503'
			}
		}
	}
}