from webbot import Browser
from bs4 import BeautifulSoup as bs
import re
import datetime as dt
from time import sleep
import os
from stdiomask import getpass
import requests

from timeTableMaker import assembleTimeTable

rows = 10
cols = 50

version = '1.2.2'
os.system(f'title BetterSimon {version}') # change window title
os.system(f'mode con: cols={cols} lines={rows}') # resize window
os.system('cls') # Needed for Ascii colors to work properly.

class aCols: # ascii colors
	dark  = '\u001b[30;1m'
	red   = '\u001b[31m'
	white = '\u001b[37;1m'
	bold  = '\u001b[1m'
	reset = '\u001b[0m'

def checkForUpdates():
	downloadPage = requests.get('https://slothagami.github.io/smallPrograms/BetterSimon.html').text
	bSoup = bs(downloadPage, 'html.parser')
	currentVersion = bSoup.select('.download-button')[0].get('href')
	
	if currentVersion != f'./Downloads/BetterSimon-{version}.zip':
		print(aCols.red+aCols.bold+'There is a new version of BetterSimon Avalable'+aCols.reset)
		print(aCols.red+'Download it here: https://slothagami.github.io/smallPrograms/BetterSimon.html'+aCols.reset)
		print('\n')

# use input for username to in distribute ver.
print('\n')
print('SIMON Login'.center(cols))

promptWidth = cols // 2
username = input('Username: '.rjust(promptWidth,' '))
password = getpass(prompt='Password: '.rjust(promptWidth,' '))

os.system('cls') # Clear the Login Stuff

print('\n')
print(f'BetterSimon {version} - Logged in as {username}'.center(cols))
print('\n')
#print(f'''
#You can find your new timetable Here: 
#{aCols.white}{os.path.join(os.getcwd(), 'New Timetable', 'timetable.html')}{aCols.reset}
#''')

checkForUpdates()

def checkSimon():
	web = Browser(showWindow=False)
	
	# Login to SIMON
	web.go_to('https://simon.tcc.vic.edu.au/') # login to simon
	web.type(username, id='inputUsername')
	web.type(password, id='inputPassword')
	web.press(web.Key.ENTER)
	
	# Get Page HTML
	pageHTML = web.get_page_source()
	soup = bs(pageHTML, 'html.parser')
	
	# Close the browser
	web.close_current_tab()
	
	# Get the Timetable Elements
	# can only get todays timetable
	
	classNameRex = re.compile(r'data-original-title="([a-zA-Z0-9 ()]*)"') # Use Regular Expressions to extract the Class names in english
	classRoomRex = re.compile(r'<span data-bind=".*">\(([a-zA-Z0-9]{1,4})\)</span>')
	elems = soup.select('#timetablePanelDesktop')
	timetable = str(elems[0])
	
	#timetable=paste()
	
	# find the class names
	results = classNameRex.findall(timetable)
	rooms = classRoomRex.findall(timetable)
	# also find the room codes
	
	if len(results) > 0:
		if results[0].replace('Homeroom','') != results[0]: # Remove Homeroom
			del results[0]
			del rooms[0]
		
	# remove any 'year X' buiseness from the names
	yearXRex = re.compile(r'Year \d+ (.*)')
	for c in range(len(results)):
		found = yearXRex.findall(results[c])
		if len(found) > 0:
			results[c] = found[0]
	
	# Make a html file of the new timetable
	assembleTimeTable(results, rooms) # saves timetable as a .html file
	
	# results should be a list of class names, can only be tested on a school day

while True:
	file = open('date.txt', 'r')
	fileDate = file.read()
	file.close()
	
	todaysDate = dt.date.today()
	if fileDate != str(todaysDate): # should run once a day, the first time the computer is opened
		file = open('date.txt', 'w')
		checkSimon()
		file.write(str(todaysDate))
		file.close()
		print(f'BetterSimon {version}- Updated Timetable - {todaysDate}')
	
	sleep(40) # checks every n seconds