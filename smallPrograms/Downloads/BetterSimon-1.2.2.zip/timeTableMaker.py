import datetime as dt

def fmtTeacherName(teacherName, roomCode=''): # removes titles from teachers names & adds room codes in brackets
	return teacherName.replace('Mr ', '').replace('Ms ', '').replace('Mrs ', '').replace('Miss ', '') + f' ({roomCode})'

def sportId(className): # if the class is sport, give that element the id 'sport'
	if 'Physical' in className or 'PE' in className:
		return 'id="sport"'
	else:
		return ''

def assembleTimeTable(classes, rooms):
	with open('New Timetable/timetable.html', 'w') as tt:
		# remove the words in brackets
		classNames = []
		teachers = []
		for class_ in range(len(classes)):
			parts = classes[class_].split('(') # parts = ['class name', 'teacher name)']
			classNames.append(parts[0])
			teachers.append(fmtTeacherName(parts[1].replace(')', ''), rooms[class_])) # remove closing bracket
			
		
		# get date (Friday, 8th of Jan)
		dayOfMonth = int(dt.datetime.now().strftime('%d')) # %d is a 0 buffered number (ranges 01 - 30)
		dayOfMonth = str(dayOfMonth)
		
		# add ordinal suffix
		if dayOfMonth == '11' or dayOfMonth == '12' or dayOfMonth == '13':
			dayOfMonth += 'th'
		elif dayOfMonth[len(dayOfMonth)-1] == '1':# if last character is
			dayOfMonth += 'st'
		elif dayOfMonth[len(dayOfMonth)-1] == '2':# if last character is
			dayOfMonth += 'nd'
		elif dayOfMonth[len(dayOfMonth)-1] == '3':# if last character is
			dayOfMonth += 'rd'
		else:
			dayOfMonth += 'th'
		
		date = dt.datetime.now().strftime(f'%A, {dayOfMonth} of %b') # add month to rest of date
		# make list of classes[i] == sport, use for setting ids of the classes
		
		# find if at least one class is sport
		sportsClasses = 0
		for className in classNames:
			if sportId(className) == 'id="sport"':
				sportsClasses += 1
		
		style = ''
		if sportsClasses > 0:
			style = '<style>body{background-image:url("sportsBackground.jpg")}</style>'
		
		# use a loop to make the timetable elements
		elems = []
		l = len(classNames)
		# do 5 times and if the list runs out elems.append('')
		for clas in range(6):
			if l > clas:
				elems.append(f'''<div class='timetable-item' {sportId(classNames[clas])}>
	<p title="{teachers[clas]}"> {classNames[clas]} </p>
</div>''')
			else:
				elems.append('')
		
		if len(classes) > 0:
			tt.write(f'''<!DOCTYPE html>
<html>
	<head>
		<title> BetterSimon Timetable </title>
		<link rel='stylesheet' href='style.css'>
		{style}
	</head>
	<body>
		<script src='scripts.js'></script>
		<div id='timetable-box'>
			<a target='_blank' href='https://simon.tcc.vic.edu.au/'><h1 title='Click Here to go to SIMON'> {date} </h1></a>
			<div id='timetable'>
				<div class='timetable-item' id='homeroom'>
					<p>Homeroom</p>
				</div>
				
				{elems[0]}
				{elems[1]}
				
				<div class='rescess'></div>
				
				{elems[2]}
				{elems[3]}
				
				<div class='rescess' id='r2'></div>
				
				{elems[4]}
			</div>
		</div>
	</body>
</html>''')
		else:
			# no timetable info case
			tt.write(f'''<!DOCTYPE html>
<html>
	<head>
		<title> BetterSimon Timetable </title>
		<link rel='stylesheet' href='style.css'>
	</head>
	<body>
		<script src='scripts.js'></script>
		<div id='timetable-box'>
			<a target='_blank' href='https://simon.tcc.vic.edu.au/'><h1 title='Click Here to go to SIMON'> {date} </h1></a>
			<div id='timetable'>
				<p id='noTimetableFound'> No Timetable could be found on SIMON (Weekend, day off or Holiday) </p>
			</div>
		</div>
	</body>
</html>''')