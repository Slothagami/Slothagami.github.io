# needs to run every morning when you turn your computer on

from webbot import Browser
from bs4 import BeautifulSoup as bs
import re
import datetime as dt
from time import sleep
import os
from stdiomask import getpass
import requests

#from pyperclip import paste

version = '1.2'

def checkForUpdates():
	downloadPage = requests.get('https://slothagami.github.io/smallPrograms/BetterSimon.html').text
	bSoup = bs(downloadPage, 'html.parser')
	currentVersion = bSoup.select('.download-button')[0].get('href')
	if currentVersion != f'./Downloads/BetterSimon-{version}.zip':
		print('''There is a new version of BetterSimon Avalable
Download it here: https://slothagami.github.io/smallPrograms/BetterSimon.html''')

# use input for username too in distribute ver.
print('\tSIMON Login')
username = input('Username: ')
password = getpass(prompt='Password: ')
# clear console after entering password, use password module?
print(f'''
BetterSimon {version} - Initialised
You can find your new timetable Here:
{os.getcwd()}\\New Timetable\\timetable.html
''')

checkForUpdates()

def sportId(className): # if the class is sport, give that element the id 'sport'
	if 'Physical' in className or 'PE' in className:
		return 'id="sport"'
	else:
		return ''

def fmtTeacherName(teacherName, roomCode=''): # removes titles from teachers names & adds room codes in brackets
	return teacherName.replace('Mr ', '').replace('Ms ', '').replace('Mrs ', '').replace('Miss ', '') + f' ({roomCode})'

def assembleTimeTable(classes, rooms):
	with open('New Timetable/timetable.html', 'w') as tt:
		# remove the words in brackets
		classNames = []
		teachers = []
		for class_ in range(len(classes)):
			parts = classes[class_].split('(') # parts = ['class name', 'teacher name)']
			classNames.append(parts[0])
			teachers.append(fmtTeacherName(parts[1].replace(')', ''), rooms[class_])) # remove closing bracket
			
		
		# get date (Friday, 8th of Jan)
		dayOfMonth = int(dt.datetime.now().strftime('%d')) # %d is a 0 buffered number (ranges 01 - 30)
		dayOfMonth = str(dayOfMonth)
		
		# add ordinal suffix
		if dayOfMonth == '11' or dayOfMonth == '12' or dayOfMonth == '13':
			dayOfMonth += 'th'
		elif dayOfMonth[len(dayOfMonth)-1] == '1':# if last character is
			dayOfMonth += 'st'
		elif dayOfMonth[len(dayOfMonth)-1] == '2':# if last character is
			dayOfMonth += 'nd'
		elif dayOfMonth[len(dayOfMonth)-1] == '3':# if last character is
			dayOfMonth += 'rd'
		else:
			dayOfMonth += 'th'
		
		date = dt.datetime.now().strftime(f'%A, {dayOfMonth} of %b') # add month to rest of date
		# make list of classes[i] == sport, use for setting ids of the classes
		
		# find if at least one class is sport
		sportsClasses = 0
		for className in classNames:
			if sportId(className) == 'id="sport"':
				sportsClasses += 1
		
		style = ''
		if sportsClasses > 0:
			style = '<style>body{background-image:url("sportsBackground.jpg")}</style>'
		
		if len(classes) > 0:
			tt.write(f'''<!DOCTYPE html>
<html>
	<head>
		<title> BetterSimon Timetable </title>
		<link rel='stylesheet' href='style.css'>
		{style}
	</head>
	<body>
		<script src='scripts.js'></script>
		<div id='timetable-box'>
			<a target='_blank' href='https://simon.tcc.vic.edu.au/'><h1 title='Click Here to go to SIMON'> {date} </h1></a>
			<div id='timetable'>
				<div class='timetable-item' id='homeroom'>
					<p>Homeroom</p>
				</div>
				<div class='timetable-item' {sportId(classNames[0])}>
					<p title="{teachers[0]}"> {classNames[0]} </p>
				</div>
				<div class='timetable-item' {sportId(classNames[1])}>
					<p title="{teachers[1]}"> {classNames[1]} </p>
				</div>
				
				
				<div class='rescess'></div>
				
				
				<div class='timetable-item' {sportId(classNames[2])}>
					<p  title="{teachers[2]}"> {classNames[2]} </p>
				</div>
				<div class='timetable-item' {sportId(classNames[3])}>
					<p  title="{teachers[3]}"> {classNames[3]} </p>
				</div>
				
				
				<div class='rescess' id='r2'></div>
				
				
				<div class='timetable-item' {sportId(classNames[4])}>
					<p  title="{teachers[4]}"> {classNames[4]} </p>
				</div>
			</div>
		</div>
	</body>
</html>''')
		else:
			# no timetable info case
			tt.write(f'''<!DOCTYPE html>
<html>
	<head>
		<title> BetterSimon Timetable </title>
		<link rel='stylesheet' href='style.css'>
	</head>
	<body>
		<script src='scripts.js'></script>
		<div id='timetable-box'>
			<a target='_blank' href='https://simon.tcc.vic.edu.au/'><h1 title='Click Here to go to SIMON'> {date} </h1></a>
			<div id='timetable'>
				<p id='noTimetableFound'> No Timetable could be found on SIMON (Weekend, day off or Holiday) </p>
			</div>
		</div>
	</body>
</html>''')

def checkSimon():
	web = Browser(showWindow=False)
	
	# Login to SIMON
	web.go_to('https://simon.tcc.vic.edu.au/') # login to simon
	web.type(username, id='inputUsername')
	web.type(password, id='inputPassword')
	web.press(web.Key.ENTER)
	
	# Get Page HTML
	pageHTML = web.get_page_source()
	soup = bs(pageHTML, 'html.parser')
	
	# Close the browser
	web.close_current_tab()
	
	# Get the Timetable Elements
	# can only get todays timetable
	
	classNameRex = re.compile(r'data-original-title="([a-zA-Z0-9 ()]*)"') # Use Regular Expressions to extract the Class names in english
	classRoomRex = re.compile(r'<span data-bind=".*">\(([a-zA-Z0-9]{1,4})\)</span>')
	elems = soup.select('#timetablePanelDesktop')
	timetable = str(elems[0])
	
	#timetable=paste()
	
	# find the class names
	results = classNameRex.findall(timetable)
	rooms = classRoomRex.findall(timetable)
	# also find the room codes
	
	if len(results) > 0:
		if results[0].replace('Homeroom','') != results[0]: # Remove Homeroom
			del results[0]
			del rooms[0]
		
	# remove any 'year X' buiseness from the names
	yearXRex = re.compile(r'Year \d+ (.*)')
	for c in range(len(results)):
		found = yearXRex.findall(results[c])
		if len(found) > 0:
			results[c] = found[0]
	
	# Make a html file of the new timetable
	assembleTimeTable(results, rooms) # saves timetable as a .html file
	
	# results should be a list of class names, can only be tested on a school day
	# compile the data into a html file like template.html in the New Timetable folder.

while True:
	file = open('date.txt', 'r')
	fileDate = file.read()
	file.close()
	
	#print(f'\nFile Contents: {fileDate}\nToday: {dt.date.today()}')
	
	if fileDate != str(dt.date.today()): # should run once a day, the first time the computer is opened
		file = open('date.txt', 'w')
		checkSimon()
		file.write(str(dt.date.today()))
		file.close()
		print(f'BetterSimon {version}- Updated Timetable - {dt.date.today()}')
	
	sleep(40) # checks every n seconds