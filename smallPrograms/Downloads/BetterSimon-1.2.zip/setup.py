# Uses Pip to install the nescicary modules for the script to run:
import os
import sys
import pip

def install(package):
    pip.main(['install', package])

if __name__ == '__main__':
    install('webbot')
    install('beautifulsoup4')
    install('stdiomask')
    install('requests')