window.onload = function(){
    setTimeout(getTimeTableElements, 350)// delay (in ms) before running
    setInterval(updateTimeMarker, 1000 * 6) // every 6s
};

var classes=[];

// https://wallpapercave.com/wp/wp5206291.png
// https://3.bp.blogspot.com/-9UsHtKKfudU/XSJyoyKd9zI/AAAAAAAAIPQ/Hda1TWYFVEAzx1a7dfFSKLxe-R4OwgfyQCKgBGAs/w0/fire-force-special-fire-force-company-8-characters-uhdpaper.com-8K-18.jpg

const minuitesPerHour = 60
const weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday', 'Saturday']
const months   = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

var _bg = window.localStorage.getItem('background'),
    _sportBg = window.localStorage.getItem('sportBackground'),
    bg = 'url('+_bg+')',
    sportBg = 'url('+_sportBg+')';

// Main Functions
function Class(name, teacher, classroom, startTime, endTime) {
    this.name = name;
    this.teacher = teacher;
    this.classroom = classroom;
    this.startTime = startTime;
    this.endTime = endTime;

    // Clean Name
    var tName = this.name;
    tName = tName.replace(/.*(Mathematics|Mathematical) /, 'Math ')
    tName = tName.replace(/.*Chemical /, 'Chem ')
    tName = tName.replace(/ Unit /, '')
    this.name = tName

    // Math Methods breaks appaerntly

    this.timetableElement = function(){
        // first work out if it's sport and flag it
        var sportRegEx = /.* (Sport|Health|HP(E)?|Physical) .*/,// looks for related words
            isSport = sportRegEx.test(this.name),
            sportTag = isSport? ' sport': '';

        if(isSport){
            document.body.style.backgroundImage = sportBg // change the background
            this.name = 'Sport'
        }

        element = [
            "<div class='timetable-item"+ sportTag +"'>",
            "\t<p title=\"" + this.teacher + " (" + this.classroom +")\">" + this.name + "</p>",
            "\t<p><span>"+ this.classroom +"</span></p>",
            "</div>"
        ]

        // add recesses if nessicary
        if(this.endTime == minuitesSinceMidnight('11','05','AM'))
            element.push("\t\t<div class='rescess'></div>")

        if(this.endTime == minuitesSinceMidnight('1','55','PM'))
            element.push("\t\t<div class='rescess' id='r2'></div>")

        return element.join('\n')
    }
}

function getTimeTableElements() {
    var elem = document.getElementsByClassName('teachingPeriod')
    for(var i = 0; i < elem.length; i++) {
        var search, em, tem, timeRange;
        search = elem[i].getElementsByTagName('td');
        em = search[2] // the title of the class is the third one
        tem = search[0] // the one with the time in it

        // Get Class Times
        timeRange = tem
        .getElementsByTagName('span')[1]
        .innerHTML;// the span with the time in it

        // timeRange currently Looks like this:
        // 10:05 AM - 11:05 AM
        // Convert 12 hour time to seconds since midnight
        // get the hours, minuites & AM/PM in list form
        var chunk, startTime, endTime;
        chunk = /(\d+):(\d+) (AM|PM) - (\d+):(\d+) ((A|P)M)/g.exec(timeRange)
        startTime = minuitesSinceMidnight(chunk[1], chunk[2], chunk[3])
        endTime = minuitesSinceMidnight(chunk[4], chunk[5], chunk[6])

        var titleElem, result, className, teacher, room;
        titleElem = em.getElementsByTagName('span')[0];

        result = getDataOriginalTitle(em.innerHTML) // get it's 'data-oringinal-title' attribute
        className = result.className;
        teacher = result.teacher;

        room = em.getElementsByTagName('span')[1].innerHTML; // the Classroom
        room = room.replaceAll(/\(|\)/g, '') // remove brackets

        classes.push(new Class(className, teacher, room, startTime, endTime))
    }

    assemblePage()
}

function assemblePage() {
    //console.log(classes)

    // Replace Everything with new timetable HTML
    document.head.innerHTML = 
        '<title>BetterSimon</title>\n'+
        '<link rel="text/stylesheet" href="Simon.css">\n'

    document.body.style.backgroundImage = bg // should be replaced if a sport object is created

    var dt = new Date(), // Make Date eg: Friday, 29th of Jan
        weekday = weekdays[dt.getDay()],
        date = dt.getDate()
        month = months[dt.getMonth()],
        fullDate = weekday + ', ' + date + ordinalSuffixOf(date) + ' of ' + month

    var newHTML = [ // Add opening HTML
		"<div id='settingsButton'>&#9776;</div>",
        "<div id='settings'>",
        "   <h1>Settings</h1>",
        "   <h4>Background<span> URL</span></h4>",
        "   <input id='bg' />",
        "",
        "   <h4>Sport's Background<span> URL</span></h4>",
        "   <input id='sbg' />",
        "",
        "   <button id='save'>Save</button>",
        "</div>",
		"<div id='timetable-box'>",
		"	<h1>" + fullDate + "</h1>",
		"	<div id='timetable'>",
		""
    ]

    // Add The timetable Stuff Here
    for(var i = 0; i < classes.length; i++) {
        newHTML.push( classes[i].timetableElement() )
    }

    newHTML.push( // Close the open Div's
        "\t</div>",
        "</div>"
    )

    document.body.innerHTML = newHTML.join('\n');

    // update the time so you don't have to wait
    updateTimeMarker()

    // Setup the added elements
    document.getElementById('settingsButton').onclick=function(){
        // Show the settings Menu
        var settingsElement = document.getElementById('settings');
        settingsElement.style.display = 'block';
    }
    document.getElementById('save').onclick=function(){
        // Hide the settings Menu
        var settingsElement = document.getElementById('settings');
        settingsElement.style.display = 'none';

        // Save the data (if its not empty)
        var bgElem = document.getElementById('bg'),
            sbgElem = document.getElementById('sbg');
        
        window.localStorage.setItem('background', bgElem.value)
        window.localStorage.setItem('sportBackground', sbgElem.value)
    }

    // Set the inputs to the stored values
    var bgElem = document.getElementById('bg'),
        sbgElem = document.getElementById('sbg');
        
        bgElem.value  = window.localStorage.getItem('background')
        sbgElem.value = window.localStorage.getItem('sportBackground')
}

function updateTimeMarker() {
    // For after the timetable has been replaced
    // for each timetable element, check if the time is within their class range,
    // and draw a line to indicate the progress through it and to
    // Blake
    // indicate the gap between classes

    var elem = document.getElementsByClassName('timetable-item'),
        dt = new Date(),
        hour = dt.getHours(),
        min = dt.getMinutes(),
        currentTime = minuitesSinceMidnight(hour, min, 'AM'), // 24 hour time, so don't add 12 if pm
        bufferTime = 8; // minuites before the range they're active (to make up for the 4 min gap between classes)
        // ^ also ammount of minuites before the class you can see where to go

    for(var i = 0; i < elem.length; i++) {
        clas = classes[i]
        if(inRange(currentTime, clas.startTime-bufferTime, clas.endTime)) {
            elem[i].style.backgroundColor = '#404040' // Highlight Color
            if(elem[i].className == 'timetable-item sport') {
                elem[i].style.backgroundColor = '#991005' // Highlight Color
            }
        } else {
            elem[i].style.backgroundColor = '#202020'
            if(elem[i].className == 'timetable-item sport') {
                elem[i].style.backgroundColor = '#2B1105'
            }
        }
    }
}

function getDataOriginalTitle(str) {
    // Uses RegEx to get the english name of the class
    var Regex, result, className, teacher;
    RegEx = /data-original-title="(.*)\((.*)\)"/g

    result = RegEx.exec(str)
    className = result[1]
    teacher = result[2]

    teacher = teacher.replace(/(Mr(s)?|Miss|Ms) /, '') // Remove teacher's title

    className = className.replace(/(Year (\d)+|(\d)+) /,'') // Remove Yr XX from start of classname

    return {teacher:teacher, className:className}
}

// Logic Functions
function minuitesSinceMidnight(hours, mins, stamp) {
    hours = parseInt(hours)
    mins  = parseInt(mins)

    var time = hours*minuitesPerHour + mins
    if(stamp == 'PM' && hours != 12){
        time += 12 * minuitesPerHour
    }

    return time;
}

function ordinalSuffixOf(n) {
    /* This Function id a modified version of the top response here:
    https://stackoverflow.com/questions/13627308/add-st-nd-rd-and-th-ordinal-suffix-to-a-number */
    var i = n % 10,
        j = n % 100;
    if (i == 1 && j != 11) return "st";
    if (i == 2 && j != 12) return "nd";
    if (i == 3 && j != 13) return "rd";

    return "th";
}

function inRange(value, min, max) {
    if(value >= min && value <= max)return true;
    return false
}