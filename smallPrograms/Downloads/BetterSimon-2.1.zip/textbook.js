// .main-page .page << The textbook bit, width: 100%; padding-top:0; 
//// #ln-content << margin: 100px
//// document.querySelector("#edjin-body > div.js-header > div.page-bg-cover") << display:none
//// document.querySelector("#edjin-body > div.main-page-blk > div.main-page.page > div.cont-body.js-body.lesson-content > div.main > div.cont-nav-blk > div")
//// ^^ Display:none
//// Blake Woolley
//// document.querySelector("#edjin-body > div.main-page-blk > div.main-page.page > div.cont-body.js-body.lesson-content > div.side-sticky-nav")
//// ^^ display:none

//document.querySelector("#edjin-body > div.js-header > div.page-bg-cover")
.style.display = 'none'

document.querySelector("#edjin-body > div.main-page-blk > div.main-page.page > div.cont-body.js-body.lesson-content > div.main > div.cont-nav-blk > div")
.style.display = 'none'

ocument.querySelector("#edjin-body > div.main-page-blk > div.main-page.page > div.cont-body.js-body.lesson-content > div.side-sticky-nav")
.style.display = 'none'

var main = document.querySelector("#edjin-body > div.main-page-blk > div.main-page.page")
main.style.width = '100%'
main.style.paddingTop = 0

document.getElementById('ln-content').style.margin = '100px'

