window.onload = function(){
    setTimeout(getTimeTableElements, 350)// delay (in ms) before running
    setInterval(updateTimeMarker, 1000 * 4) // every 4s
};

/*
    Make the backgrounds cycle through the list before resetting 
    (stops any one bg appearing too much)

    Add optional Prompt for SIMON Student ID to use other features
    Create list of objects in the fetch().then() function

    
    Unsaved Changes:
        Removed Classroom Codes from timetable
        Changed cmd Delimiter to ':'
            Changed sg function names to strings (They can now include spaces)
        added option to move menu to the right with the ``right`` addition to the ...
            ... end of the url (for when the focous of the image is on the left)
        Fixed names breaking when you have a substitute teacher

*/

const minuitesPerHour = 60
const weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday', 'Saturday']
const months   = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
const sg = { // In an object so they are listed in the console as a group
    // Theese Functions can only have one argument
    // The arguments will always be a string
    'count words': function(str) {
        return str.split(' ').length
    },
    'factor': function(n) {
        n = parseInt(n)
        var factors = []
        for(var i = 0; i < n+1; i++) {
            if(n % i == 0) factors.push(i)
        }
        return factors
    }
}

function makeTasksSection(studentId='637248735364129260') {
    if(studentId == undefined) return

    fetch(
        "https://simon.tcc.vic.edu.au/Default.asmx/GetClassResources?" + studentId, 
        {
            "headers": {
                "accept": "application/json, text/javascript, */*; q=0.01",
                "accept-language": "en-US,en;q=0.9,ja;q=0.8",
                "content-type": "application/json; charset=UTF-8",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-requested-with": "XMLHttpRequest"
            },
            "referrer": "https://simon.tcc.vic.edu.au/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "{\"FileSeq\":null,\"UserID\":null}",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        }
    ).then(function(response){
        return response.json()
    }).then(function(data){
        //console.log(data.d)
        // Make the HTML Section
        generateTaskObjects(data.d)
    });
}
function generateTaskObjects(data) {
    // Clean the data

    // Remove unwanted entries
    var wantedEntries = ['OverDueTasksStudent', 'DueTasksStudent', 'ResultTasksStudent'],
        cleanData = {}

    for(var i in wantedEntries)
        cleanData[wantedEntries[i]] = data[wantedEntries[i]]
        
    // Clean the Class Info
    // Needed Data: ClassName, TaskName, TaskStatus, DueDate
    // in format (str): %ClassName%, %TaskName% - (%TaskStatus%|Due %DueDate%)

    //console.log(cleanData)
    var newData = {}
    for(var i in wantedEntries) {
        if(wantedEntries[i].length == 0) continue // Skip empty arrays

        newData[wantedEntries[i]] = []

        for(var j in cleanData[wantedEntries[i]]) {
            index = cleanData[wantedEntries[i]][j] // for every list item in the key

            newData[wantedEntries[i]].push( 
                new TaskResult(
                    wantedEntries[i]=='ResultTasksStudent'?
                        index.Description:
                        index.ClassDescription,

                    wantedEntries[i]=='DueTasksStudent'?
                        index.dueDate: 
                        undefined,

                    wantedEntries[i]=='ResultTasksStudent'?
                        index.Tasks[0].Title:
                        index.TaskTitle,

                    wantedEntries[i]=='ResultTasksStudent'?
                        index.Tasks[0].FinalResult:
                        undefined
                )
            )
        }
    }

    //console.log(newData)

    // Make HTML Element
    var html = '<div id="task-box">'

    for(var i in wantedEntries) {
        // append title here
        //title = wantedEntries[i]==''?
        //html += title 

        for(var j in newData[wantedEntries[i]]) {
            html += newData[wantedEntries[i]][j].makeElement()
        }
    }

    html += '</div>'

    //document.getElementById('results-box').innerHTML = html
    
    //console.log(html)
}

var classes=[],
    _bg = window.localStorage.getItem('background'),
    _sportBg = window.localStorage.getItem('sportBackground'),
    bg = 'url('+ backgroundFromData(_bg) +')',
    sportBg = 'url('+ backgroundFromData(_sportBg) +')';

// Main Functions
class Class {
    constructor(name, teacher, classroom, startTime, endTime) {
        this.name = name;
        this.teacher = teacher;
        this.classroom = classroom;
        this.startTime = startTime;
        this.endTime = endTime;

        this.name = cleanClassName(this.name)
    }

    timetableElement() {
        // first work out if it's sport and flag it
        var sportRegEx = /.* (Sport|Health|HP(E)?|Physical) .*/,// looks for related words
            isSport = sportRegEx.test(this.name),
            sportTag = isSport? ' sport': '',
            element;

        if(isSport){
            document.body.style.backgroundImage = sportBg // change the background
            this.name = 'Sport'
        }

        element = [
            "<div class='timetable-item"+ sportTag +"'>",
            "\t<p title=\"" + this.teacher + " (" + this.classroom +")\">" + this.name + "</p>",
            //"\t<p><span>"+ this.classroom +"</span></p>",
            "</div>"
        ]

        // add recesses if nessicary
        if(this.endTime == minuitesSinceMidnight('11','05','AM'))
            element.push("\t\t<div class='rescess'></div>")

        if(this.endTime == minuitesSinceMidnight('1','55','PM'))
            element.push("\t\t<div class='rescess' id='r2'></div>")

        return element.join('\n')
    }
}
class TaskResult {
    constructor(className, dueDate, taskTitle, finalResult) {
        this.className = className;
        this.dueDate = dueDate;
        this.taskTitle = taskTitle;
        this.finalResult = finalResult;

        this.className = cleanClassName(this.className)
    }

    toString() {
        var endP = this.finalResult == undefined? 
            'Due ' + this.dueDate:
            this.finalResult
        
        if(this.finalResult == undefined && this.dueDate == undefined)
            endP = ''

        return this.className +', '+ this.taskTitle +'\n'+endP
    }
    print() {
        console.log(this.toString())
    }
    makeElement() {
        // Returns a HTML Element of it's data
        var parts = this.toString().split('\n')
        return '<div class="task">'+ parts[0] +'\n<span>'+ parts[1] +'</span></div>'
    }
}

function cleanClassName(name) {
    name = name.replace(/.*(Mathematics|Mathematical) /, 'Math ')
    name = name.replace(/.*Chemical /, 'Chem ')
    name = name.replace(/ Unit /, '')
    name = name.replace(/Year \d+ /, '')
    return name
}
function getTimeTableElements() {
    var elem = document.getElementsByClassName('teachingPeriod')
    for(var i = 0; i < elem.length; i++) {
        var timeRange,
            search = elem[i].getElementsByTagName('td'),
            em     = search[2], // the title of the class is the third one
            tem    = search[0]  // the one with the time in it

        // Get Class Times
        timeRange = tem
            .getElementsByTagName('span')[1]
            .innerHTML; // the span with the time in it

        // timeRange currently Looks like this:
        // 10:05 AM - 11:05 AM
        // Convert 12 hour time to seconds since midnight
        // get the hours, minuites & AM/PM in list form
        var chunk     = /(\d+):(\d+) (AM|PM) - (\d+):(\d+) ((A|P)M)/g.exec(timeRange),
            startTime = minuitesSinceMidnight(chunk[1], chunk[2], chunk[3]),
            endTime   = minuitesSinceMidnight(chunk[4], chunk[5], chunk[6])

        var titleElem, result, className, teacher, room;
        titleElem = em.getElementsByTagName('span')[0];

        result    = getDataOriginalTitle(em.innerHTML) // get it's 'data-oringinal-title' attribute
        className = result.className;
        teacher   = result.teacher;

        room = em.getElementsByTagName('span')[1].innerHTML; // the Classroom
        room = room.replaceAll(/\(|\)/g, '') // remove brackets

        classes.push(new Class(className, teacher, room, startTime, endTime))
    }

    assemblePage()
}
function assemblePage() {
    // Replace Everything with new timetable HTML
    document.head.innerHTML = 
        '<title>BetterSimon</title>\n'+
        '<link rel="text/stylesheet" href="Simon.css">\n'

    document.body.style.backgroundImage = bg // should be replaced if a sport object is created

    var dt = new Date(), // Make Date eg: Friday, 29th of Jan
        weekday = weekdays[dt.getDay()],
        date = dt.getDate()
        month = months[dt.getMonth()],
        fullDate = weekday + ', ' + date + ordinalSuffixOf(date) + ' of ' + month

    var newHTML = [ // Add opening HTML
		"<div id='settingsButton'>&#9776;</div>",
        "<div id='settings'>",
        "   <h1>Backgrounds</h1>",
        "   <p>You can seperate multiple backgrounds with a comma.</p>",
        "   <h4>Backgrounds<span> URL</span></h4>",
        "   <textarea rows='12' id='ta-bg'></textarea>",
        "",
        "   <h4>Sport Day Backgrounds<span> URL</span></h4>",
        "   <textarea rows='12' id='ta-sbg'></textarea>",
        "",
        "   <button id='save'>Save</button>",
        "</div>",
        "",
		"<div id='timetable-box'>",
		"	<h1>" + fullDate + "</h1>",
		"	<div id='timetable'>",
		"	<div id='pointer'></div>",
        ""
    ]

    // Add The timetable Stuff Here
    for(var i = 0; i < classes.length; i++) {
        newHTML.push( classes[i].timetableElement() )
    }

    newHTML.push( // Close the open Div's
        "\t</div>",
        "</div>",
        "<textarea rows='2' id='run-func'></textarea>",
        //"<div id='results-box'></div>"
    )

    document.body.innerHTML = newHTML.join('\n');

    // update the time so you don't have to wait
    updateTimeMarker()

    // Setup the added elements
    document.getElementById('settingsButton').onclick=function(){
        // Show the settings Menu
        var settingsElement = document.getElementById('settings');
        settingsElement.style.display = 'block';
    }
    document.getElementById('save').onclick=function(){
        // Hide the settings Menu
        var settingsElement = document.getElementById('settings');
        settingsElement.style.display = 'none';

        // Save the data (if its not empty)
        var bgElem = document.getElementById('ta-bg'),
            sbgElem = document.getElementById('ta-sbg');
        
        window.localStorage.setItem('background', bgElem.value)
        window.localStorage.setItem('sportBackground', sbgElem.value)
    }

    // Handle Commands in hidden textbox
    var cmdBox = document.getElementById('run-func');

    // Decode String
    cmdBox.addEventListener('keydown',function(e){
        if(e.key == 'Enter' && !e.shiftKey) { // Shift + enter for newline
            let delimiter = ':'
            var command = cmdBox.value.split(delimiter)[0],
                arg = cmdBox.value.replace(command + delimiter, ''),
                result;

            try {
                result = sg[command](arg)
            } catch (e) {
                if(e instanceof TypeError) { // if unknown command, just count the words
                    result = sg.countWords(cmdBox.value) + ' words.'
                }
            }
            
            alert(result)
            cmdBox.value = ''
        }
    })

    // Set the inputs to the stored values
    var bgElem = document.getElementById('ta-bg'),
        sbgElem = document.getElementById('ta-sbg');
        
        bgElem.value  = window.localStorage.getItem('background')
        sbgElem.value = window.localStorage.getItem('sportBackground')

    // Load Student ID from LocalStorage
    makeTasksSection()

}
function updateTimeMarker() {
    // For after the timetable has been replaced
    // for each timetable element, check if the time is within their class range,
    // Blake

    var elem = document.getElementsByClassName('timetable-item'),
        dt   = new Date(),
        hour = dt.getHours(),
        min  = dt.getMinutes(),
        currentTime = minuitesSinceMidnight(hour, min, 'AM'), // 24 hour time, so don't add 12 if pm
        bufferTime  = 8, // minuites before the range they're active (to make up for the 4 min gap between classes)
        // ^ also ammount of minuites before the class you can see where to go
        pointer  = document.getElementById('pointer'),
        recesses = document.getElementsByClassName('rescess'),
        timetableBox = document.getElementById('timetable').getBoundingClientRect(),
        start = 0, end = 1;
    
    // Loop the recesses to ipdate time marker
    for(var i = 0; i < recesses.length; i++) {
        var elementTimeRange = recesses[i].id == 'r2'? 
            [ // Break 2 Times
                minuitesSinceMidnight( 1,55, 'PM'),
                minuitesSinceMidnight( 2,17, 'PM')
            ]:
            [ // Break 1 times
                minuitesSinceMidnight(11,05, 'AM'), 
                minuitesSinceMidnight(11,49, 'AM')
            ]

        if(inRange(currentTime, elementTimeRange[start], elementTimeRange[end])) {
            // position the pointer
            var bbox = recesses[i].getBoundingClientRect(),
                timeSinceStart = currentTime - elementTimeRange[start]
                length = elementTimeRange[end] - elementTimeRange[start],
                progress = timeSinceStart / length,

                y = (bbox.y + bbox.height * progress) - timetableBox.y,
            
            pointer.style.transform = 'translate(0,'+ y +'px)'
        }
    }

    // Loop Classes to update time marker
    for(var i = 0; i < elem.length; i++) {
        clas = classes[i]

        if(inRange(currentTime, clas.startTime-bufferTime, clas.endTime)) {
            elem[i].style.backgroundColor = '#353535' // Highlight Color

            if(elem[i].className == 'timetable-item sport') 
                elem[i].style.backgroundColor = '#991005' // Highlight Color

            // Move the marker to here with the appropriate percent across (do for recess?)
            // move #pointer.style.transform = 'translate(0, bbox-top + percent of height)'
            var rect = elem[i].getBoundingClientRect(),
                eTop = rect.y - timetableBox.y, // To compensate for not being at the top of the screen
                eHeight = rect.height,

                classLength = clas.endTime - clas.startTime,
                timeSinceClassStart = currentTime - clas.startTime,
                classProgress = timeSinceClassStart / classLength

            // Top of the class element + the width * progress in it
            pointer.style.transform = 'translate(0, '+ (eTop + eHeight * classProgress) +'px)'

        } else {
            elem[i].style.backgroundColor = '#202020'

            if(elem[i].className == 'timetable-item sport') 
                elem[i].style.backgroundColor = '#2B1105'
        }
    }
}
function getDataOriginalTitle(str) {
    // Uses RegEx to get the english name of the class
    var regex, result, className, teacher;
    regex = /data-original-title="(.*)"/g

    result    = regex.exec(str)[1]
    let split = result.split('(')

    className = split[0]
    teacher   = split[1].replace(')', '')

    teacher = teacher.replace(/(Mr(s)?|Miss|Ms) /, '') // Remove teacher's title

    className = className.replace(/(Year (\d)+|(\d)+) /,'') // Remove Yr XX from start of classname

    return {teacher:teacher, className:className}
}

// Logic Functions
function minuitesSinceMidnight(hours, mins, stamp) {
    var time;

    if(mins == undefined && stanp == undefined) {
        // Case for one arument given (24hr time as a string)
        var split = hours.split(':'),
            hours = parseInt(split[0]),
            mins  = parseInt(split[1])

        time = hours * minuitesPerHour + mins

    }else{
        hours = parseInt(hours)
        mins  = parseInt(mins)

        time = hours*minuitesPerHour + mins
        if(stamp == 'PM' && hours != 12)
            time += 12 * minuitesPerHour
    }
    return time;
}
function ordinalSuffixOf(n) {
    /* This Function id a modified version of the top response here:
    https://stackoverflow.com/questions/13627308/add-st-nd-rd-and-th-ordinal-suffix-to-a-number */
    var i = n % 10,
        j = n % 100;
    if (i == 1 && j != 11) return "st";
    if (i == 2 && j != 12) return "nd";
    if (i == 3 && j != 13) return "rd";

    return "th";
}
function inRange(value, min, max) {
    if(value >= min && value <= max)return true;
    return false
}
function backgroundFromData(str) {
    // Seperate comma seperated values, return a random index
    // If list index ends with a ``right`` put the timetable on the right and the settings on the left
    // (for images focoused to the left)
    // and ``random`` option, for if it focuses on both sides
    urls = str.split(',');
    url = urls[Math.round(Math.random()*(urls.length-1))].trim()

    // Find any ``right`` at the end, remove it if it exists, and flip the menus if needed
    let rightIndicator = '``right``'
    if(url.endsWith(rightIndicator)) {
        url = url.replace(rightIndicator, '')

        // Switch Floats of #timetable-box and #settingsButton
        rightSideTimetable = true
        setTimeout( ()=> {
            let style = document.createElement('style')
            style.innerText = [
                '#timetable-box{float:right}',
                '#settingsButton{float:left}',
                '#settings{float:left}',
                '#run-func{position:absolute;bottom:15px;right:15px;}'
            ].join('\n')

            document.getElementsByTagName('head')[0].appendChild(style);
        }, 1000)
    }

    return url
}