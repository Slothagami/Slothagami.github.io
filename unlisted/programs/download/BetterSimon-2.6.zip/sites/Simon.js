window.onload = function(){
    // delay before running to  make sure timetable is loaded
    setTimeout(getTimeTableElements, 350)
    setInterval(updateTimeMarker, 1000 * 4)
};

/*  Make Better UI For Adding Backgrounds, 
    settings, convert to string already 
    being used for seamless transition     */

const storage = window.localStorage
var classes=[],
    bg       = background(storage.getItem('background')),
    sportBg  = background(storage.getItem('sportBackground'))

// Main Functions
class Class {
    constructor(name, teacher, classroom, startTime, endTime) {
        this.name      = name;
        this.teacher   = teacher;
        this.classroom = classroom;
        this.startTime = startTime;
        this.endTime   = endTime;
        this.name      = Class.cleanName(this.name)
    }

    timetableElement() {
        // Flag Sport Classes
        let isSport = /.* (Sport|Health|HP(E)?|Physical) .*/.test(this.name),
            sportTag = isSport? 'sport': ''

        if(isSport){
            setBackground(sportBg)
            this.name = 'Sport'
        }

        let element = [
            `<div class='timetable-item ${sportTag}'>`,
                `<p title="${this.teacher} (${this.classroom})">${this.name}</p>`,
            "</div>"
        ]

        // add recesses if nessicary
        if(this.endTime == toMinuites('11','05','AM'))
            element.push("<div class='rescess'></div>")

        if(this.endTime == toMinuites('1','55','PM'))
            element.push("<div class='rescess' id='r2'></div>")

        return element.join('\n')
    }

    static cleanName(name) {
        // Convert To Abbreviations and remove redundant words
        return name
            .replace(/.*(Mathematics|Mathematical) /, 'Math ')
            .replace(/.*Chemical /, 'Chem ')
            .replace(/ Unit /, '')
            .replace(/Year \d+ /, '')
    }

    static getTitle(str) {
        // Uses RegEx to get the actual name of the class
        // get the 'data-oringinal-title' attribute
        var result = /data-original-title="(.*)"/g
            .exec(str)[1].split("("), 
        className = result[0], 
        teacher   = result[1].replace(')', '');

        teacher   = teacher.replace(/(Mr(s)?|Miss|Ms) /,    '') // Remove teacher's title
        className = className.replace(/(Year (\d)+|(\d)+) /,'') // Remove Yr XX from start of classname

        return {
            teacher:   teacher, 
            className: className
        }
    }

    static timeRangeFromString(str) {
        // "10:05 AM - 11:05 AM" -> {start: 605, end: 665}
        var chunk = /(\d+):(\d+) (AM|PM) - (\d+):(\d+) ((A|P)M)/g.exec(str)
        return {
            start: toMinuites(chunk[1], chunk[2], chunk[3]),
            end:   toMinuites(chunk[4], chunk[5], chunk[6])
        }
    }
}

function getTimeTableElements() {
    for(let elem of document.getElementsByClassName('teachingPeriod')) {

        let search    = elem.getElementsByTagName('td'),
            titleEm   = search[2], // the title of the class
            timeRange = search[0].getElementsByTagName('span')[1] // the time of the class 
            timeRange = Class.timeRangeFromString(timeRange.innerHTML)

        let class_ = Class.getTitle(titleEm.innerHTML),
            room = titleEm.getElementsByTagName('span')[1].innerHTML;

        room = room.replaceAll(/\(|\)/g, '') // remove brackets

        classes.push(new Class(
            class_.className, 
            class_.teacher, 
            room, 
            timeRange.start, 
            timeRange.end
        ))
    }

    assemblePage()
}
function assemblePage() {
    // Replace Everything with the new HTML
    setBackground(bg) // will be replaced if a sport class is found

    document.head.innerHTML = 
        '<title>BetterSimon</title>'+
        '<link rel="text/stylesheet" href="Simon.css">'

    var newHTML = [ // Add opening HTML
		"<div id='settingsButton'>&#9776;</div>",
        "<div id='settings'>",
            "<h1>Backgrounds</h1>",
            "<p>You can seperate multiple backgrounds with a comma.</p>",
            "<h4>Backgrounds<span> URL</span></h4>",
            "<textarea rows='12' id='ta-bg'></textarea>",

            "<h4>Sport Day Backgrounds<span> URL</span></h4>",
            "<textarea rows='12' id='ta-sbg'></textarea>",

            "<button id='save'>Save</button>",
        "</div>",

		"<div id='timetable-box'>",
		    "<h1>" + wordedDate() + "</h1>",
		    "<div id='timetable'>",
		    "<div id='pointer'></div>",
    ]

    // Add The timetable Stuff
    for(let _class of classes)
        newHTML.push(_class.timetableElement())

    newHTML.push("</div></div>")
    document.body.innerHTML = newHTML.join('\n');
    updateTimeMarker()

    // Setup elements
    document.getElementById('settingsButton').onclick = ()=>{
        document.getElementById('settings')
            .style.display = 'block'; // Show settings Menu
    }

    document.getElementById('save').onclick = ()=>{
        document.getElementById('settings')
            .style.display = 'none'; // Hide the settings Menu

        // Save the data (if its not empty)
        var bgElem  = document.getElementById('ta-bg'),
            sbgElem = document.getElementById('ta-sbg');
        
        storage.setItem('background',      bgElem.value)
        storage.setItem('sportBackground', sbgElem.value)
    }

    // Set the inputs to the stored values
    var bgElem  = document.getElementById('ta-bg'),
        sbgElem = document.getElementById('ta-sbg');
        
        bgElem.value  = storage.getItem('background')
        sbgElem.value = storage.getItem('sportBackground')
}
function updateTimeMarker() {
    // For after the timetable has been replaced
    // for each timetable element, check if the time is within their class range

    let elems       = document.getElementsByClassName('timetable-item'),
        dt          = new Date(),
        currentTime = toMinuites(dt.getHours(), dt.getMinutes(), 'AM'),
        bufferTime  = 8, 
        // ^ minuites before the range they're active (to make up for the 4 min gap between classes)
        // ^ also ammount of minuites before the class you can see where to go
        pointer      = document.getElementById('pointer'),
        recesses     = document.getElementsByClassName('rescess'),
        timetableBox = document.getElementById('timetable').getBoundingClientRect(),
        start = 0, end = 1;
    
    // Loop the recesses to update time marker
    for(let recess of recesses) {
        let elementTimeRange = recess.id == 'r2'? 
            [toMinuites( 1,55, 'PM'), // Break 2 Times
             toMinuites( 2,17, 'PM')]:

            [toMinuites(11,05, 'AM'), // Break 1 times
             toMinuites(11,49, 'AM')]

        if(inRange(currentTime, elementTimeRange[start], elementTimeRange[end])) {
            // position the pointer
            var bbox           = recess.getBoundingClientRect(),
                timeSinceStart = currentTime - elementTimeRange[start]
                length         = elementTimeRange[end] - elementTimeRange[start],
                progress       = timeSinceStart / length,

                y = (bbox.y + bbox.height * progress) - timetableBox.y,
            
            pointer.style.transform = `translate(0,${y}px)`
        }
    }

    // Loop Classes to update time marker
    for(var i = 0; i < elems.length; i++) {
        elem = elems[i]
        clas = classes[i]

        if(inRange(currentTime, clas.startTime-bufferTime, clas.endTime)) {
            elem.style.backgroundColor = 
                window.getComputedStyle(elem, ':active').getPropertyValue('background-color')

            // Move the marker to here with the appropriate percent across (do for recess?)
            // move #pointer.style.transform = 'translate(0, bbox-top + percent of height)'
            var rect    = elem.getBoundingClientRect(),
                eTop    = rect.y - timetableBox.y, // To compensate for not being at the top of the screen
                eHeight = rect.height,

                classLength         = clas.endTime - clas.startTime,
                timeSinceClassStart = currentTime  - clas.startTime,
                classProgress       = timeSinceClassStart / classLength

            // Top of the class element + the width * progress in it
            pointer.style.transform = `translate(0, ${eTop + eHeight * classProgress}px)`

        } else {
            elem.style.backgroundColor = 
                window.getComputedStyle(elem).getPropertyValue('background-color')
        }
    }
}

// Logic Functions
function toMinuites(hours, mins, stamp) {
    hours = parseInt(hours)
    mins  = parseInt(mins)

    let minuitesPerHour = 60,
        time = hours * minuitesPerHour + mins

    if(stamp == 'PM' && hours != 12)
        time += 12 * minuitesPerHour

    return time;
}
function ordinalSuffixOf(n) {
    /* This Function id a modified version of the top response here:
    https://stackoverflow.com/questions/13627308/add-st-nd-rd-and-th-ordinal-suffix-to-a-number */
    var i = n % 10,
        j = n % 100;
    if (i == 1 && j != 11) return "st";
    if (i == 2 && j != 12) return "nd";
    if (i == 3 && j != 13) return "rd";

    return "th";
}
function inRange(value, min, max) {
    return value >= min && value <= max
}
function background(str) {
    // add ``random`` option, for if it focuses on both sides

    // Return random index of "," Delimited List
    let urls = str.split(','),
        index = Math.round(Math.random() * (urls.length - 1))
        url = urls[index].trim()

    // If list index ends with a ``right``,
    // put the timetable on the right and the settings on the left
    let rightIndicator = '``right``'
    if(url.endsWith(rightIndicator)) {
        url = url.replace(rightIndicator, '')

        // Switch Floats of #timetable-box and #settingsButton
        rightSideTimetable = true
        setTimeout( ()=> {
            let style = document.createElement('style')
            style.innerText = [
                '#timetable-box{float:right}',
                '#settingsButton{float:left}',
                '#settings{float:left}',
                '#run-func{position:absolute;bottom:15px;right:15px;}'
            ].join('\n')

            document.head.appendChild(style);
        }, 1000)
    }

    return `url(${url})`
}
function setBackground(bg) {
    document.body.style.backgroundImage = bg
}
function wordedDate() {
    // Make Date eg: Friday, 29th of Jan
    let weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday', 'Saturday']
    let months   = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    let dt = new Date(), 
        weekday = weekdays[dt.getDay()],
        date = dt.getDate()
        month = months[dt.getMonth()]

    return `${weekday}, ${date + ordinalSuffixOf(date)} of ${month}`
}