window.onload = function(){
    // delay before running to  make sure timetable is loaded
    setTimeout(getTimeTableElements, 350)
    setInterval(updateTimeMarker, 1000 * 4)
};

const storage = window.localStorage
var classes=[]

var bgs = [{
    name:"Default Background",
    url: "https://ak.picdn.net/shutterstock/videos/24364160/thumb/8.jpg",
    allignment: "random"
}]
var sbgs = [{
    name:"Default Background",
    url: "https://ak.picdn.net/shutterstock/videos/24364160/thumb/8.jpg",
    allignment: "random"
}]

if(storage.getItem("background")) {
    // Assume both are set
    bgs  = JSON.parse(storage.getItem("background"))
    sbgs = JSON.parse(storage.getItem("sportBackground"))
}

// Set the random Backgrounds
var bg       = background(bgs),
    sportBg  = background(sbgs)

// Main Functions
class Class {
    constructor(name, teacher, classroom, startTime, endTime) {
        this.name      = name;
        this.teacher   = teacher;
        this.classroom = classroom;
        this.startTime = startTime;
        this.endTime   = endTime;
        this.name      = Class.cleanName(this.name)
    }

    timetableElement() {
        // Flag Sport Classes
        let isSport = /.* (Sport|Health|HP(E)?|Physical) .*/.test(this.name),
            sportTag = isSport? 'sport': ''

        if(isSport){
            setBackground(sportBg)
            this.name = 'Sport'
        }

        let element = [
            `<div class='timetable-item ${sportTag}'>`,
                `<p title="${this.teacher} (${this.classroom})">${this.name}</p>`,
            "</div>"
        ]

        // add recesses if nessicary
        if(this.endTime == toMinuites('11','05','AM'))
            element.push("<div class='rescess'></div>")

        if(this.endTime == toMinuites('1','55','PM'))
            element.push("<div class='rescess' id='r2'></div>")

        return element.join('\n')
    }

    static cleanName(name) {
        // Convert To Abbreviations and remove redundant words
        return name
            .replace(/.*(Mathematics|Mathematical) /, 'Math ')
            .replace(/.*Chemical /, 'Chem ')
            .replace(/ Unit /, '')
            .replace(/Year \d+ /, '')
    }

    static getTitle(str) {
        // Uses RegEx to get the actual name of the class
        // get the 'data-oringinal-title' attribute
        var result = /data-original-title="(.*)"/g
            .exec(str)[1].split("("), 
        className = result[0], 
        teacher   = result[1].replace(')', '');

        teacher   = teacher.replace(/(Mr(s)?|Miss|Ms) /,    '') // Remove teacher's title
        className = className.replace(/(Year (\d)+|(\d)+) /,'') // Remove Yr XX from start of classname

        return {
            teacher:   teacher, 
            className: className
        }
    }

    static timeRangeFromString(str) {
        // "10:05 AM - 11:05 AM" -> {start: 605, end: 665}
        var chunk = /(\d+):(\d+) (AM|PM) - (\d+):(\d+) ((A|P)M)/g.exec(str)
        return {
            start: toMinuites(chunk[1], chunk[2], chunk[3]),
            end:   toMinuites(chunk[4], chunk[5], chunk[6])
        }
    }
}

function getTimeTableElements() {
    for(let elem of document.getElementsByClassName('teachingPeriod')) {

        let search    = elem.getElementsByTagName('td'),
            titleEm   = search[2], // the title of the class
            timeRange = search[0].getElementsByTagName('span')[1] // the time of the class 
            timeRange = Class.timeRangeFromString(timeRange.innerHTML)

        let class_ = Class.getTitle(titleEm.innerHTML),
            room = titleEm.getElementsByTagName('span')[1].innerHTML;

        room = room.replaceAll(/\(|\)/g, '') // remove brackets

        classes.push(new Class(
            class_.className, 
            class_.teacher, 
            room, 
            timeRange.start, 
            timeRange.end
        ))
    }

    assemblePage()
}
function assemblePage() {
    // Replace Everything with the new HTML
    setBackground(bg) // will be replaced if a sport class is found

    document.head.innerHTML = 
        '<title>BetterSimon</title>'+
        '<link rel="text/stylesheet" href="Simon.css">'

    var newHTML = [ // Add opening HTML
		"<div id='settingsButton'>&#9776;</div>",
        "<div id='settings'>",
            "<h1>Backgrounds</h1>",
            "<div id='backgrounds-box'></div>",

            "<h4>Sport Day Backgrounds</h4>",
            "<div id='sport-backgrounds-box'></div>",

            "<button id='save'>Save</button>",
        "</div>",

		"<div id='timetable-box'>",
		    "<h1>" + wordedDate() + "</h1>",
		    "<div id='timetable'>",
		    "<div id='pointer'></div>",
    ]

    // Add The timetable Stuff
    for(let _class of classes)
        newHTML.push(_class.timetableElement())

    newHTML.push("</div></div>")
    document.body.innerHTML = newHTML.join('\n');
    updateTimeMarker()

    // Setup elements
    document.getElementById('settingsButton').onclick = ()=>{
        document.getElementById('settings')
            .style.display = 'block'; // Show settings Menu
    }

    document.getElementById('save').onclick = ()=>{
        document.getElementById('settings')
            .style.display = 'none'; // Hide the settings Menu
        
        storage.setItem('background',      JSON.stringify(bgs ))
        storage.setItem('sportBackground', JSON.stringify(sbgs))
    }

    // Setup Background menu
    generateBgList(document.getElementById("backgrounds-box"),       bgs )
    generateBgList(document.getElementById("sport-backgrounds-box"), sbgs)
}
function updateTimeMarker() {
    // For after the timetable has been replaced
    // for each timetable element, check if the time is within their class range

    let elems       = document.getElementsByClassName('timetable-item'),
        dt          = new Date(),
        currentTime = toMinuites(dt.getHours(), dt.getMinutes(), 'AM'),
        bufferTime  = 8, 
        // ^ minuites before the range they're active (to make up for the 4 min gap between classes)
        // ^ also ammount of minuites before the class you can see where to go
        pointer      = document.getElementById('pointer'),
        recesses     = document.getElementsByClassName('rescess'),
        timetableBox = document.getElementById('timetable').getBoundingClientRect(),
        start = 0, end = 1;
    
    // Loop the recesses to update time marker
    for(let recess of recesses) {
        let elementTimeRange = recess.id == 'r2'? 
            [toMinuites( 1,55, 'PM'), // Break 2 Times
             toMinuites( 2,17, 'PM')]:

            [toMinuites(11,05, 'AM'), // Break 1 times
             toMinuites(11,49, 'AM')]

        if(inRange(currentTime, elementTimeRange[start], elementTimeRange[end])) {
            // position the pointer
            var bbox           = recess.getBoundingClientRect(),
                timeSinceStart = currentTime - elementTimeRange[start]
                length         = elementTimeRange[end] - elementTimeRange[start],
                progress       = timeSinceStart / length,

                y = (bbox.y + bbox.height * progress) - timetableBox.y,
            
            pointer.style.transform = `translate(0,${y}px)`
        }
    }

    // Loop Classes to update time marker
    for(var i = 0; i < elems.length; i++) {
        elem = elems[i]
        clas = classes[i]

        if(inRange(currentTime, clas.startTime-bufferTime, clas.endTime)) {
            elem.style.backgroundColor = 
                window.getComputedStyle(elem, ':active').getPropertyValue('background-color')

            // Move the marker to here with the appropriate percent across (do for recess?)
            // move #pointer.style.transform = 'translate(0, bbox-top + percent of height)'
            var rect    = elem.getBoundingClientRect(),
                eTop    = rect.y - timetableBox.y, // To compensate for not being at the top of the screen
                eHeight = rect.height,

                classLength         = clas.endTime - clas.startTime,
                timeSinceClassStart = currentTime  - clas.startTime,
                classProgress       = timeSinceClassStart / classLength

            // Top of the class element + the width * progress in it
            pointer.style.transform = `translate(0, ${eTop + eHeight * classProgress}px)`

        } else {
            elem.style.backgroundColor = 
                window.getComputedStyle(elem).getPropertyValue('background-color')
        }
    }
}

function generateBgList(root, list) {
    root.innerHTML = ""
    //console.log(list)

    // Assemble bg menus
    for(let bg of list) {
        let container = document.createElement("div")
            container.className = "background-settings-box"

        let h2 = document.createElement("h2")
            h2.innerText = bg.name
            //h2.onclick = (e) => { console.log(e);removeBg(h2, root, list) }

        let span = document.createElement("span")
            span.innerText = " " + fmtUrl(bg.url) + " "

        let data = document.createElement("data")
            data.value = list.indexOf(bg)

        // Select Menu
        let select = document.createElement("select")
            select.name = "Timetable Position"
            select.onchange = () => {
                // Update the data
                let index = select.parentElement.querySelector("data").value

                list[index].allignment = select.value
            }

        let options = ["Left", "Right", "Random"]
        for(option of options) {
            let op = document.createElement("option")
                op.value = option.toLowerCase()
                op.innerText = option

            select.appendChild(op)
        }
        select.value = bg.allignment

        // Organise it all
        container.appendChild(h2)
        container.appendChild(span)
        container.appendChild(data)
        container.appendChild(select)

        // Add click event (set as current bg)
        container.onclick = () => {
            let url = container.querySelector("span").innerHTML,
                opt = container.querySelector("select").value
            setBackground(url, opt)
        }
        // Effectively on rightclick
        container.oncontextmenu = () => { 
            removeBg(h2, root, list); 
            return false// return false to stop context menu appearing
        } 

        root.appendChild(container)
    }

    let button = document.createElement("button")
        button.innerText = "Add"
        button.onclick = ()=>{ addBg(root, list) }

    root.appendChild(button)
}
function fmtUrl(name) {
    return `url(${name})`
}
function addBg(root, list) {
    let url  = window.prompt("Url To Image:"),
        name = window.prompt("Name of Background:")

    if(url == "" || url == null || name == "" || name == null) return

    list.push({
        "name": name,
        "url": url,
        "allignment": "random" // Random is default
    })
    generateBgList(root, list)
}
function removeBg(bg, root, list) {
    if(!confirm("Delete this Background?")) return
    let index = bg.parentElement.querySelector("data").value

    list.splice(index, 1)
    generateBgList(root, list)
}

// Logic Functions
function toMinuites(hours, mins, stamp) {
    hours = parseInt(hours)
    mins  = parseInt(mins)

    let minuitesPerHour = 60,
        time = hours * minuitesPerHour + mins

    if(stamp == 'PM' && hours != 12)
        time += 12 * minuitesPerHour

    return time;
}
function ordinalSuffixOf(n) {
    /* This Function id a modified version of the top response here:
    https://stackoverflow.com/questions/13627308/add-st-nd-rd-and-th-ordinal-suffix-to-a-number */
    var i = n % 10,
        j = n % 100;
    if (i == 1 && j != 11) return "st";
    if (i == 2 && j != 12) return "nd";
    if (i == 3 && j != 13) return "rd";

    return "th";
}
function inRange(value, min, max) {
    return value >= min && value <= max
}
function background(list) {
    if(!list) return // If invalid string, don't even try
    // Choose a random entry to use for the background
    var chosenBG = list[Math.floor(Math.random() * list.length)]
    var allignment = chosenBG.allignment // new var to not change original
    
    if(chosenBG.allignment == "random") {
        if(Math.random() <= .5) // 50% chance of swapping sides
            allignment = "right"
    }
    if(chosenBG.allignment == "right") {
        // swap side
        rightSideTimetable = true
        setTimeout( ()=> {
            let style = document.createElement('style')
            style.innerText = [
                '#timetable-box{right:0}',
                '#settingsButton{float:left}',
                '#settings{float:left}'
            ].join('\n')

            document.head.appendChild(style);
        }, 1000)
    }

    return `url(${chosenBG.url})`
}
function setBackground(bg, allign=undefined) {
    document.body.style.backgroundImage = bg

    if(allign != undefined) {
        // remove any style elements from head
        try {
            document.head.removeChild(
                document.head.querySelector("style")
            )
        } catch {} // has to be there, doesn't need to do anything

        if(allign == "random") {
            if(Math.random() <= .5) // 50% chance of swapping sides
                allign = "right"
        }

        if(allign == "right") {
            // swap side
            rightSideTimetable = true
            //setTimeout( ()=> {
                let style = document.createElement('style')
                style.innerText = [
                    '#timetable-box{right:0}',
                    '#settingsButton{float:left}',
                    '#settings{float:left}'
                ].join('\n')
    
                document.head.appendChild(style);
            //}, 1000)
        }
    }
}
function wordedDate() {
    // Make Date eg: Friday, 29th of Jan
    let weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday', 'Saturday']
    let months   = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    let dt = new Date(), 
        weekday = weekdays[dt.getDay()],
        date = dt.getDate()
        month = months[dt.getMonth()]

    return `${weekday}, ${date + ordinalSuffixOf(date)} of ${month}`
}